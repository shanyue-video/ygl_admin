var require = meteorInstall({"lib":{"collections":{"applys.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/applys.js                                                                             //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
var _mongo = require('meteor/mongo');                                                                    // 1
                                                                                                         //
var Applys = new _mongo.Mongo.Collection('applys');                                                      // 3
                                                                                                         //
exports['default'] = Applys;                                                                             //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"badges.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/badges.js                                                                             //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
var _mongo = require('meteor/mongo');                                                                    // 1
                                                                                                         //
var Badges = new _mongo.Mongo.Collection('badges');                                                      // 3
                                                                                                         //
exports['default'] = Badges;                                                                             //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"bankcards.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/bankcards.js                                                                          //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
var _mongo = require('meteor/mongo');                                                                    // 1
                                                                                                         //
var Bankcards = new _mongo.Mongo.Collection('bankcards');                                                // 3
                                                                                                         //
exports['default'] = Bankcards;                                                                          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"banners.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/banners.js                                                                            //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
var _mongo = require('meteor/mongo');                                                                    // 1
                                                                                                         //
var Banners = new _mongo.Mongo.Collection('banners');                                                    // 3
                                                                                                         //
exports['default'] = Banners;                                                                            //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"departments.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/departments.js                                                                        //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
var _mongo = require('meteor/mongo');                                                                    // 1
                                                                                                         //
var Departments = new _mongo.Mongo.Collection('departments');                                            // 3
                                                                                                         //
exports['default'] = Departments;                                                                        //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"discuz_applys.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/discuz_applys.js                                                                      //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
var _mongo = require('meteor/mongo');                                                                    // 1
                                                                                                         //
var DiscuzApplys = new _mongo.Mongo.Collection('discuz_applys');                                         // 3
                                                                                                         //
exports['default'] = DiscuzApplys;                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"discuzmessages.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/discuzmessages.js                                                                     //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
var _mongo = require('meteor/mongo');                                                                    // 1
                                                                                                         //
var Discuzmessages = new _mongo.Mongo.Collection('discuzmessages');                                      // 3
                                                                                                         //
exports['default'] = Discuzmessages;                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"discuzs.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/discuzs.js                                                                            //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
var _mongo = require('meteor/mongo');                                                                    // 1
                                                                                                         //
var Discuzs = new _mongo.Mongo.Collection('discuzs');                                                    // 3
                                                                                                         //
exports['default'] = Discuzs;                                                                            //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"doctors.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/doctors.js                                                                            //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
var _mongo = require('meteor/mongo');                                                                    // 1
                                                                                                         //
var Doctors = new _mongo.Mongo.Collection('doctors');                                                    // 3
                                                                                                         //
exports['default'] = Doctors;                                                                            //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"feilds.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/feilds.js                                                                             //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
var _mongo = require('meteor/mongo');                                                                    // 1
                                                                                                         //
var Feilds = new _mongo.Mongo.Collection('feilds');                                                      // 3
                                                                                                         //
exports['default'] = Feilds;                                                                             //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"hospitals.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/hospitals.js                                                                          //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
var _mongo = require('meteor/mongo');                                                                    // 1
                                                                                                         //
var Hospitals = new _mongo.Mongo.Collection('hospitals');                                                // 3
                                                                                                         //
exports['default'] = Hospitals;                                                                          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./applys","./bankcards","./banners","./discuzs","./discuzmessages","./discuz_applys","./doctors","./news","./recommands","./referrals","./regions","./hospitals","./departments","./badges","./user_badges","./feilds",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/index.js                                                                              //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
exports.Feilds = exports.UserBadges = exports.Badges = exports.Departments = exports.Hospitals = exports.Regions = exports.Referrals = exports.Recommands = exports.News = exports.Doctors = exports.DiscuzApplys = exports.Discuzmessages = exports.Discuzs = exports.Banners = exports.Bankcards = exports.Applys = exports.undefined = undefined;
                                                                                                         //
var _applys = require('./applys');                                                                       // 1
                                                                                                         //
var _applys2 = _interopRequireDefault(_applys);                                                          //
                                                                                                         //
var _bankcards = require('./bankcards');                                                                 // 2
                                                                                                         //
var _bankcards2 = _interopRequireDefault(_bankcards);                                                    //
                                                                                                         //
var _banners = require('./banners');                                                                     // 3
                                                                                                         //
var _banners2 = _interopRequireDefault(_banners);                                                        //
                                                                                                         //
var _discuzs = require('./discuzs');                                                                     // 4
                                                                                                         //
var _discuzs2 = _interopRequireDefault(_discuzs);                                                        //
                                                                                                         //
var _discuzmessages = require('./discuzmessages');                                                       // 5
                                                                                                         //
var _discuzmessages2 = _interopRequireDefault(_discuzmessages);                                          //
                                                                                                         //
var _discuz_applys = require('./discuz_applys');                                                         // 6
                                                                                                         //
var _discuz_applys2 = _interopRequireDefault(_discuz_applys);                                            //
                                                                                                         //
var _doctors = require('./doctors');                                                                     // 7
                                                                                                         //
var _doctors2 = _interopRequireDefault(_doctors);                                                        //
                                                                                                         //
var _news = require('./news');                                                                           // 8
                                                                                                         //
var _news2 = _interopRequireDefault(_news);                                                              //
                                                                                                         //
var _recommands = require('./recommands');                                                               // 9
                                                                                                         //
var _recommands2 = _interopRequireDefault(_recommands);                                                  //
                                                                                                         //
var _referrals = require('./referrals');                                                                 // 10
                                                                                                         //
var _referrals2 = _interopRequireDefault(_referrals);                                                    //
                                                                                                         //
var _regions = require('./regions');                                                                     // 11
                                                                                                         //
var _regions2 = _interopRequireDefault(_regions);                                                        //
                                                                                                         //
var _hospitals = require('./hospitals');                                                                 // 12
                                                                                                         //
var _hospitals2 = _interopRequireDefault(_hospitals);                                                    //
                                                                                                         //
var _departments = require('./departments');                                                             // 13
                                                                                                         //
var _departments2 = _interopRequireDefault(_departments);                                                //
                                                                                                         //
var _badges = require('./badges');                                                                       // 14
                                                                                                         //
var _badges2 = _interopRequireDefault(_badges);                                                          //
                                                                                                         //
var _user_badges = require('./user_badges');                                                             // 15
                                                                                                         //
var _user_badges2 = _interopRequireDefault(_user_badges);                                                //
                                                                                                         //
var _feilds = require('./feilds');                                                                       // 16
                                                                                                         //
var _feilds2 = _interopRequireDefault(_feilds);                                                          //
                                                                                                         //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }        //
                                                                                                         //
exports.undefined = undefined;                                                                           //
exports.Applys = _applys2['default'];                                                                    //
exports.Bankcards = _bankcards2['default'];                                                              //
exports.Banners = _banners2['default'];                                                                  //
exports.Discuzs = _discuzs2['default'];                                                                  //
exports.Discuzmessages = _discuzmessages2['default'];                                                    //
exports.DiscuzApplys = _discuz_applys2['default'];                                                       //
exports.Doctors = _doctors2['default'];                                                                  //
exports.News = _news2['default'];                                                                        //
exports.Recommands = _recommands2['default'];                                                            //
exports.Referrals = _referrals2['default'];                                                              //
exports.Regions = _regions2['default'];                                                                  //
exports.Hospitals = _hospitals2['default'];                                                              //
exports.Departments = _departments2['default'];                                                          //
exports.Badges = _badges2['default'];                                                                    //
exports.UserBadges = _user_badges2['default'];                                                           //
exports.Feilds = _feilds2['default'];                                                                    //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"news.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/news.js                                                                               //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
var _mongo = require('meteor/mongo');                                                                    // 1
                                                                                                         //
var News = new _mongo.Mongo.Collection('news');                                                          // 3
                                                                                                         //
exports['default'] = News;                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"recommands.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/recommands.js                                                                         //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
var _mongo = require('meteor/mongo');                                                                    // 1
                                                                                                         //
var Recommands = new _mongo.Mongo.Collection('recommands');                                              // 3
                                                                                                         //
exports['default'] = Recommands;                                                                         //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"referrals.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/referrals.js                                                                          //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
var _mongo = require('meteor/mongo');                                                                    // 1
                                                                                                         //
var Referrals = new _mongo.Mongo.Collection('referrals');                                                // 3
                                                                                                         //
exports['default'] = Referrals;                                                                          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"regions.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/regions.js                                                                            //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
var _mongo = require('meteor/mongo');                                                                    // 1
                                                                                                         //
var Regions = new _mongo.Mongo.Collection('regions');                                                    // 3
                                                                                                         //
exports['default'] = Regions;                                                                            //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"user_badges.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/collections/user_badges.js                                                                        //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
var _mongo = require('meteor/mongo');                                                                    // 1
                                                                                                         //
var UserBadges = new _mongo.Mongo.Collection('user_badges');                                             // 3
                                                                                                         //
exports['default'] = UserBadges;                                                                         //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"model":{"facc.js":["meteor/meteor",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/model/facc.js                                                                                     //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
"use strict";                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
    value: true                                                                                          //
});                                                                                                      //
                                                                                                         //
var _meteor = require("meteor/meteor");                                                                  // 2
                                                                                                         //
var facc = {                                                                                             // 4
    _id: "FAMILYOFDEVELOPOER",                                                                           // 5
    user: function user() {                                                                              // 6
        return {                                                                                         // 7
            "_id": localStorage.getItem(facc._id + "_UID"),                                              // 8
            "nickname": localStorage.getItem(facc._id + "_NICK"),                                        // 9
            "avatar": localStorage.getItem(facc._id + "_AVATAR")                                         // 10
        };                                                                                               // 7
    },                                                                                                   // 12
    set: function set(user) {                                                                            // 13
        _meteor.Meteor.connection.setUserId(user._id);                                                   // 14
        localStorage.setItem(facc._id + "_UID", user._id);                                               // 15
        localStorage.setItem(facc._id + "_NICK", user.nickname);                                         // 16
        localStorage.setItem(facc._id + "_AVATAR", user.avatar);                                         // 17
    },                                                                                                   // 18
    logout: function logout() {                                                                          // 19
        localStorage.removeItem(facc._id + "_UID");                                                      // 20
        localStorage.removeItem(facc._id + "_NICK");                                                     // 21
        localStorage.removeItem(facc._id + "_AVATAR");                                                   // 22
        _meteor.Meteor.logout();                                                                         // 23
    },                                                                                                   // 24
    isGuest: function isGuest() {                                                                        // 25
        return localStorage.getItem(facc._id + "_UID") ? false : true;                                   // 26
    },                                                                                                   // 27
    sms: {                                                                                               // 28
        server: 'http://222.73.117.158/msg/HttpBatchSendSM?',                                            // 29
        account: "",                                                                                     // 30
        pwd: ""                                                                                          // 31
    },                                                                                                   // 28
    checkUsername: function checkUsername(str) {                                                         // 33
        return str.match(/^[a-zA-Z0-9_]{1,}$/);                                                          // 34
    },                                                                                                   // 35
    checkTel: function checkTel(str) {                                                                   // 36
        return str.match(/^0?1[3|4|5|8][0-9]\d{8}$/);                                                    // 37
    },                                                                                                   // 38
    backto: function backto() {                                                                          // 39
        FlowRouter.go("/");                                                                              // 40
    },                                                                                                   // 41
    needAdmin: 1                                                                                         // 42
}; ///*                                                                                                  // 4
                                                                                                         //
                                                                                                         //
exports["default"] = facc;                                                                               //
//*/                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./facc",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// lib/model/index.js                                                                                    //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
    value: true                                                                                          //
});                                                                                                      //
exports.facc = undefined;                                                                                //
                                                                                                         //
var _facc = require('./facc');                                                                           // 2
                                                                                                         //
var _facc2 = _interopRequireDefault(_facc);                                                              //
                                                                                                         //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }        //
                                                                                                         //
exports.facc = _facc2['default'];                                                                        //
//*/                                                                                                     //
///*                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"configs":{"index.js":["./sms","./oss",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/configs/index.js                                                                               //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
    value: true                                                                                          //
});                                                                                                      //
exports.upload = exports.sms = undefined;                                                                //
                                                                                                         //
var _sms = require('./sms');                                                                             // 1
                                                                                                         //
var _sms2 = _interopRequireDefault(_sms);                                                                //
                                                                                                         //
var _oss = require('./oss');                                                                             // 2
                                                                                                         //
var _oss2 = _interopRequireDefault(_oss);                                                                //
                                                                                                         //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }        //
                                                                                                         //
exports.sms = _sms2['default'];                                                                          //
exports.upload = _oss2['default'];                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"oss.js":["meteor/meteor","aliyun-sdk/index.js",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/configs/oss.js                                                                                 //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
    value: true                                                                                          //
});                                                                                                      //
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 1
                                                                                                         //
var ALY = require('aliyun-sdk/index.js');                                                                // 3
                                                                                                         //
var oss = new ALY.OSS({                                                                                  // 5
    accessKeyId: "yYlOJE1T4NmsAi69",                                                                     // 6
    secretAccessKey: "Rgq8ToXYEcp5Xn28oOWyfRRyD5Y3U5",                                                   // 7
    endpoint: "http://oss-cn-beijing.aliyuncs.com", //测试环境                                               // 8
    //endpoint: 'http://oss-cn-beijing-internal.aliyuncs.com', //线上环境                                    //
    apiVersion: '2013-10-15'                                                                             // 10
});                                                                                                      // 5
                                                                                                         //
var upload = function upload(img, callback) {                                                            // 13
                                                                                                         //
    var prefix = img.substr(0, img.indexOf("base64") + 7);                                               // 15
                                                                                                         //
    var ext = "jpg";                                                                                     // 17
    var mine = "image/jpeg";                                                                             // 18
    if (prefix.indexOf("png") > 0) {                                                                     // 19
        ext = "png";                                                                                     // 20
        mine = "image/png";                                                                              // 21
    } else if (prefix.indexOf("gif") > 0) {                                                              // 22
        ext = "gif";                                                                                     // 23
        mine = "image/gif";                                                                              // 24
    }                                                                                                    // 25
                                                                                                         //
    var name = "asset/" + parseInt(Math.random() * 10000000000) + "." + ext;                             // 27
                                                                                                         //
    var data = img.replace(/^data:image\/\w+;base64,/, "");                                              // 29
    var base64 = new Buffer(data, "base64");                                                             // 30
                                                                                                         //
    var url = "http://cdn.yigonglue.com/" + name;                                                        // 33
    oss.putObject({                                                                                      // 34
        Bucket: 'yglweb',                                                                                // 35
        Key: name, // 注意, Key 的值不能以 / 开头, 否则会返回错误.                                                       // 36
        Body: base64,                                                                                    // 37
        AccessControlAllowOrigin: '*',                                                                   // 38
        ContentType: mine,                                                                               // 39
        CacheControl: 'no-cache', // 参考: http://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html#sec14.9  // 40
        ContentDisposition: '', // 参考: http://www.w3.org/Protocols/rfc2616/rfc2616-sec19.html#sec19.5.1  // 41
        ContentEncoding: 'utf-8', // 参考: http://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html#sec14.11
        ServerSideEncryption: 'AES256',                                                                  // 43
        Expires: null // 参考: http://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html#sec14.21             // 44
    }, _meteor.Meteor.bindEnvironment(function (err, msg) {                                              // 34
        if (err) {                                                                                       // 47
            console.log(err);                                                                            // 48
        } else {                                                                                         // 49
            callback(url);                                                                               // 50
        }                                                                                                // 51
    }));                                                                                                 // 53
};                                                                                                       // 55
                                                                                                         //
exports['default'] = upload;                                                                             //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"sms.js":["meteor/http",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/configs/sms.js                                                                                 //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
    value: true                                                                                          //
});                                                                                                      //
                                                                                                         //
var _http = require('meteor/http');                                                                      // 1
                                                                                                         //
var sms = {                                                                                              // 3
    // uid=1234&auth=faea920f7412b5da7be0cf42b8c93759&mobile=13612345678&msg=hello&expid=0               //
    server: 'http://210.5.158.31:9011/hy/?',                                                             // 5
                                                                                                         //
    uid: "8085911",                                                                                      // 7
    code: "ygl2016",                                                                                     // 8
    pwd: "ygl2016",                                                                                      // 9
                                                                                                         //
    send: function send(tel, html) {                                                                     // 11
        console.log("======SMS========");                                                                // 12
        console.log("tel:" + tel);                                                                       // 13
        console.log("html:" + html);                                                                     // 14
        console.log("sms.uid:" + sms.uid);                                                               // 15
        console.log("sms.code:" + sms.code);                                                             // 16
        console.log("sms.pwd:" + sms.pwd);                                                               // 17
        console.log("sms.server:" + sms.server);                                                         // 18
        _http.HTTP.get(sms.server, {                                                                     // 19
            params: {                                                                                    // 20
                uid: sms.uid,                                                                            // 21
                auth: CryptoJS.MD5(sms.code + sms.pwd).toString().toLowerCase(),                         // 22
                mobile: tel,                                                                             // 23
                msg: html,                                                                               // 24
                expid: 0,                                                                                // 25
                encode: "utf-8"                                                                          // 26
            }                                                                                            // 20
        }, function (error, result) {                                                                    // 19
            if (!error) {                                                                                // 29
                console.log("SMS-RES:" + result.content);                                                // 30
            } else {                                                                                     // 31
                console.log("SMS-ERR:" + error);                                                         // 32
            }                                                                                            // 33
        });                                                                                              // 34
        console.log("======SMS-SEND========");                                                           // 35
    }                                                                                                    // 36
};                                                                                                       // 3
                                                                                                         //
exports['default'] = sms;                                                                                //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods":{"account_login_with_tel.js":["meteor/meteor","meteor/check","/lib/model","meteor/jparker:crypto-core",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/methods/account_login_with_tel.js                                                              //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
    value: true                                                                                          //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
    _meteor.Meteor.methods({                                                                             // 7
        'account_login_with_tel.sample': function account_login_with_telSample(args) {                   // 8
            if (args.tel == "" || !_model.facc.checkTel(args.tel)) {                                     // 9
                return "ERROR_UNKONE";                                                                   // 10
            }                                                                                            // 11
                                                                                                         //
            var user = _meteor.Meteor.users.findOne({                                                    // 13
                tel: args.tel                                                                            // 14
            });                                                                                          // 13
                                                                                                         //
            if (!user) {                                                                                 // 17
                return "ERROR_NONE";                                                                     // 18
            }                                                                                            // 19
                                                                                                         //
            if (_model.facc.needAdmin == 1 && user.isadmin != 1) {                                       // 21
                return "ERROR_RIGHT";                                                                    // 22
            }                                                                                            // 23
                                                                                                         //
            var salt = user.salt;                                                                        // 25
            var md5 = _jparkerCryptoCore.CryptoJS.MD5(args.password + salt).toString();                  // 26
                                                                                                         //
            //if (md5 != user.password) {                                                                //
            //    return "ERROR_PWD";                                                                    //
            //}                                                                                          //
                                                                                                         //
            this.setUserId(user._id);                                                                    // 32
                                                                                                         //
            return {                                                                                     // 34
                "_id": user._id,                                                                         // 35
                "nickname": user.nickname,                                                               // 36
                "avatar": user.avatar                                                                    // 37
            };                                                                                           // 34
        }                                                                                                // 39
    });                                                                                                  // 7
};                                                                                                       // 41
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 1
                                                                                                         //
var _check = require('meteor/check');                                                                    // 2
                                                                                                         //
var _model = require('/lib/model');                                                                      // 3
                                                                                                         //
var _jparkerCryptoCore = require('meteor/jparker:crypto-core');                                          // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"agree_point_apply.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/methods/agree_point_apply.js                                                                   //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
    value: true                                                                                          //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
    _meteor.Meteor.methods({                                                                             // 6
        'agree_point_apply.sample': function agree_point_applySample(args) {                             // 7
            var obj = _collections.Applys.findOne({                                                      // 8
                _id: args._id                                                                            // 9
            });                                                                                          // 8
            if (!obj.checked) {                                                                          // 11
                _collections.Applys.update({ _id: args._id }, { $set: { check: 1 } });                   // 12
                _meteor.Meteor.users.update({                                                            // 13
                    _id: obj.userid                                                                      // 14
                }, {                                                                                     // 13
                    $inc: {                                                                              // 16
                        balance: obj.balance * -1                                                        // 17
                    }                                                                                    // 16
                });                                                                                      // 15
                                                                                                         //
                _collections.Tracks.insert({                                                             // 21
                    userid: obj.userid,                                                                  // 22
                    balance: obj.balance * -1,                                                           // 23
                    createAt: new Date(),                                                                // 24
                    status: 1,                                                                           // 25
                    desc: "已发送到您的帐户请查收",                                                                 // 26
                    type: "APPLYCASH",                                                                   // 27
                    typeName: "申请通过"                                                                     // 28
                                                                                                         //
                });                                                                                      // 21
            }                                                                                            // 31
            //console.log(obj);                                                                          //
        }                                                                                                // 33
    });                                                                                                  // 6
};                                                                                                       // 35
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./account_login_with_tel","./agree_point_apply","./upload_banner_thumb","./upload_discuz_thumb","./pass_the_member_vaild","./set_the_member_master","./save_user_info","./upload_news_thumb","./notify_referral","./upload_records_tables_thumb","./uploadhospital_thumb",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/methods/index.js                                                                               //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  (0, _account_login_with_tel2['default'])();                                                            // 14
  (0, _agree_point_apply2['default'])();                                                                 // 15
  (0, _upload_banner_thumb2['default'])();                                                               // 16
  (0, _upload_discuz_thumb2['default'])();                                                               // 17
  (0, _pass_the_member_vaild2['default'])();                                                             // 18
  (0, _set_the_member_master2['default'])();                                                             // 19
  (0, _save_user_info2['default'])();                                                                    // 20
  (0, _upload_news_thumb2['default'])();                                                                 // 21
  (0, _notify_referral2['default'])();                                                                   // 22
  (0, _upload_records_tables_thumb2['default'])();                                                       // 23
  (0, _uploadhospital_thumb2['default'])();                                                              // 24
};                                                                                                       // 25
                                                                                                         //
var _account_login_with_tel = require('./account_login_with_tel');                                       // 1
                                                                                                         //
var _account_login_with_tel2 = _interopRequireDefault(_account_login_with_tel);                          //
                                                                                                         //
var _agree_point_apply = require('./agree_point_apply');                                                 // 2
                                                                                                         //
var _agree_point_apply2 = _interopRequireDefault(_agree_point_apply);                                    //
                                                                                                         //
var _upload_banner_thumb = require('./upload_banner_thumb');                                             // 3
                                                                                                         //
var _upload_banner_thumb2 = _interopRequireDefault(_upload_banner_thumb);                                //
                                                                                                         //
var _upload_discuz_thumb = require('./upload_discuz_thumb');                                             // 4
                                                                                                         //
var _upload_discuz_thumb2 = _interopRequireDefault(_upload_discuz_thumb);                                //
                                                                                                         //
var _pass_the_member_vaild = require('./pass_the_member_vaild');                                         // 5
                                                                                                         //
var _pass_the_member_vaild2 = _interopRequireDefault(_pass_the_member_vaild);                            //
                                                                                                         //
var _set_the_member_master = require('./set_the_member_master');                                         // 6
                                                                                                         //
var _set_the_member_master2 = _interopRequireDefault(_set_the_member_master);                            //
                                                                                                         //
var _save_user_info = require('./save_user_info');                                                       // 7
                                                                                                         //
var _save_user_info2 = _interopRequireDefault(_save_user_info);                                          //
                                                                                                         //
var _upload_news_thumb = require('./upload_news_thumb');                                                 // 8
                                                                                                         //
var _upload_news_thumb2 = _interopRequireDefault(_upload_news_thumb);                                    //
                                                                                                         //
var _notify_referral = require('./notify_referral');                                                     // 9
                                                                                                         //
var _notify_referral2 = _interopRequireDefault(_notify_referral);                                        //
                                                                                                         //
var _upload_records_tables_thumb = require('./upload_records_tables_thumb');                             // 10
                                                                                                         //
var _upload_records_tables_thumb2 = _interopRequireDefault(_upload_records_tables_thumb);                //
                                                                                                         //
var _uploadhospital_thumb = require('./uploadhospital_thumb');                                           // 11
                                                                                                         //
var _uploadhospital_thumb2 = _interopRequireDefault(_uploadhospital_thumb);                              //
                                                                                                         //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }        //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"notify_referral.js":["/lib/collections","meteor/meteor","meteor/check","/lib/model",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/methods/notify_referral.js                                                                     //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.methods({                                                                               // 7
    'notify_referral.sample': function notify_referralSample(args) {                                     // 8
      var doc = _collections.Doctors.findOne({ _id: args.doctor });                                      // 9
      var ref = _collections.Referrals.findOne({ _id: args.referral });                                  // 10
      if (doc && ref) {                                                                                  // 11
        var user = _meteor.Meteor.users.findOne({ _id: doc.userid });                                    // 12
        _model.sms.send(user.tel, "为您指派了一个转诊请尽快登陆APP查看.");                                               // 13
      }                                                                                                  // 14
    }                                                                                                    // 15
  });                                                                                                    // 7
};                                                                                                       // 17
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
                                                                                                         //
var _model = require('/lib/model');                                                                      // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"pass_the_member_vaild.js":["meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/methods/pass_the_member_vaild.js                                                               //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.methods({                                                                               // 5
    'pass_the_member_vaild.sample': function pass_the_member_vaildSample() {                             // 6
      _meteor.Meteor.users.update({ _id: args.uid }, { $set: { vaild: 1 } });                            // 7
    }                                                                                                    // 8
  });                                                                                                    // 5
};                                                                                                       // 10
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 1
                                                                                                         //
var _check = require('meteor/check');                                                                    // 2
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"save_user_info.js":["meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/methods/save_user_info.js                                                                      //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.methods({                                                                               // 5
    'save_user_info.sample': function save_user_infoSample(args) {                                       // 6
      _meteor.Meteor.users.update(args.select, {                                                         // 7
        $set: {                                                                                          // 8
          point: args.fields.point,                                                                      // 9
          balance: args.fields.balance,                                                                  // 10
          isadmin: args.fields.isadmin,                                                                  // 11
          master: args.fields.master,                                                                    // 12
          vaild: args.fields.vaild,                                                                      // 13
          role: args.fields.role                                                                         // 14
        }                                                                                                // 8
      });                                                                                                // 7
    }                                                                                                    // 17
  });                                                                                                    // 5
};                                                                                                       // 19
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 1
                                                                                                         //
var _check = require('meteor/check');                                                                    // 2
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"set_the_member_master.js":["meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/methods/set_the_member_master.js                                                               //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.methods({                                                                               // 5
    'set_the_member_master.sample': function set_the_member_masterSample(args) {                         // 6
      _meteor.Meteor.users.update({ _id: args.uid }, { $set: { master: args.master } });                 // 7
    }                                                                                                    // 8
  });                                                                                                    // 5
};                                                                                                       // 10
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 1
                                                                                                         //
var _check = require('meteor/check');                                                                    // 2
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"upload_banner_thumb.js":["/lib/collections","meteor/meteor","meteor/check","../configs",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/methods/upload_banner_thumb.js                                                                 //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
    value: true                                                                                          //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
    _meteor.Meteor.methods({                                                                             // 7
        'upload_banner_thumb.sample': function upload_banner_thumbSample(args) {                         // 8
            var obj = _collections.Banners.findOne({                                                     // 9
                _id: args._id                                                                            // 10
            });                                                                                          // 9
            (0, _configs.upload)(obj.thumb, function (data) {                                            // 12
                _collections.Banners.update({                                                            // 13
                    _id: args._id                                                                        // 14
                }, {                                                                                     // 13
                    $set: {                                                                              // 16
                        "thumb": data                                                                    // 17
                    }                                                                                    // 16
                });                                                                                      // 15
            }, function (e) {                                                                            // 20
                throw e;                                                                                 // 21
            });                                                                                          // 22
        },                                                                                               // 23
        'banner_insert': function banner_insert(args) {                                                  // 24
            _collections.Banners.insert(args, function (err, __id) {                                     // 25
                var obj = _collections.Banners.findOne({                                                 // 26
                    _id: __id                                                                            // 27
                });                                                                                      // 26
                (0, _configs.upload)(obj.thumb, function (data) {                                        // 29
                    _collections.Banners.update({                                                        // 30
                        _id: args._id                                                                    // 31
                    }, {                                                                                 // 30
                        $set: {                                                                          // 33
                            "thumb": data                                                                // 34
                        }                                                                                // 33
                    });                                                                                  // 32
                }, function (e) {                                                                        // 37
                    throw e;                                                                             // 38
                });                                                                                      // 39
            });                                                                                          // 40
        },                                                                                               // 41
        'banner_update': function banner_update(args) {                                                  // 42
            _collections.Banners.update({                                                                // 43
                _id: args.__id                                                                           // 44
            }, {                                                                                         // 43
                $set: args.obj                                                                           // 46
            });                                                                                          // 45
            //console.log('---');                                                                        //
            //console.log(__id);                                                                         //
            //console.log(x);                                                                            //
            //var obj = Banners.findOne({                                                                //
            //    _id: __id                                                                              //
            //});                                                                                        //
            var obj = args.obj;                                                                          // 54
            if (obj.thumb && obj.thumb.indexOf("base64") > -1) {                                         // 55
                (0, _configs.upload)(obj.thumb, function (data) {                                        // 56
                    _collections.Banners.update({                                                        // 57
                        _id: args._id                                                                    // 58
                    }, {                                                                                 // 57
                        $set: {                                                                          // 60
                            "thumb": data                                                                // 61
                        }                                                                                // 60
                    });                                                                                  // 59
                }, function (e) {                                                                        // 64
                    throw e;                                                                             // 65
                });                                                                                      // 66
            }                                                                                            // 67
        }                                                                                                // 68
    });                                                                                                  // 7
};                                                                                                       // 70
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
                                                                                                         //
var _configs = require('../configs');                                                                    // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"upload_discuz_thumb.js":["/lib/collections","meteor/meteor","meteor/check","../configs",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/methods/upload_discuz_thumb.js                                                                 //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.methods({                                                                               // 7
    'upload_discuz_thumb.sample': function upload_discuz_thumbSample(args) {                             // 8
      var discuz = _collections.Discuzs.findOne({                                                        // 9
        _id: args._id                                                                                    // 10
      });                                                                                                // 9
      (0, _configs.upload)(discuz.thumb, function (data) {                                               // 12
        _collections.Discuzs.update({                                                                    // 13
          _id: args._id                                                                                  // 14
        }, {                                                                                             // 13
          $set: {                                                                                        // 16
            "thumb": data                                                                                // 17
          }                                                                                              // 16
        });                                                                                              // 15
      }, function (e) {                                                                                  // 20
        throw e;                                                                                         // 21
      });                                                                                                // 22
    }                                                                                                    // 23
  });                                                                                                    // 7
};                                                                                                       // 25
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
                                                                                                         //
var _configs = require('../configs');                                                                    // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"upload_news_thumb.js":["/lib/collections","meteor/meteor","meteor/check","../configs",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/methods/upload_news_thumb.js                                                                   //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.methods({                                                                               // 7
    'upload_news_thumb.sample': function upload_news_thumbSample(args) {                                 // 8
      var obj = _collections.News.findOne({                                                              // 9
        _id: args._id                                                                                    // 10
      });                                                                                                // 9
      (0, _configs.upload)(obj.thumb, function (data) {                                                  // 12
        _collections.News.update({                                                                       // 13
          _id: args._id                                                                                  // 14
        }, {                                                                                             // 13
          $set: {                                                                                        // 16
            "thumb": data                                                                                // 17
          }                                                                                              // 16
        });                                                                                              // 15
      }, function (e) {                                                                                  // 20
        throw e;                                                                                         // 21
      });                                                                                                // 22
    }                                                                                                    // 23
  });                                                                                                    // 7
};                                                                                                       // 25
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
                                                                                                         //
var _configs = require('../configs');                                                                    // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"upload_records_tables_thumb.js":["/lib/collections","meteor/meteor","meteor/check","../configs",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/methods/upload_records_tables_thumb.js                                                         //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.methods({                                                                               // 7
    'upload_records_tables_thumb.sample': function upload_records_tables_thumbSample(args) {             // 8
      var rt = _collections.RecordsTables.findOne({                                                      // 9
        _id: args._id                                                                                    // 10
      });                                                                                                // 9
                                                                                                         //
      (0, _configs.upload)(rt.thumb, function (data) {                                                   // 13
        _collections.RecordsTables.update({                                                              // 14
          _id: args._id                                                                                  // 15
        }, {                                                                                             // 14
          $set: {                                                                                        // 17
            "thumb": data                                                                                // 18
          }                                                                                              // 17
        });                                                                                              // 16
      }, function (e) {                                                                                  // 21
        throw e;                                                                                         // 22
      });                                                                                                // 23
    }                                                                                                    // 24
  });                                                                                                    // 7
};                                                                                                       // 26
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
                                                                                                         //
var _configs = require('../configs');                                                                    // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"uploadhospital_thumb.js":["/lib/collections","meteor/meteor","meteor/check","../configs",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/methods/uploadhospital_thumb.js                                                                //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.methods({                                                                               // 7
    'uploadhospital_thumb.sample': function uploadhospital_thumbSample() {                               // 8
      var rt = _collections.Hospitals.findOne({                                                          // 9
        _id: args._id                                                                                    // 10
      });                                                                                                // 9
                                                                                                         //
      (0, _configs.upload)(rt.thumb, function (data) {                                                   // 13
        _collections.Hospitals.update({                                                                  // 14
          _id: args._id                                                                                  // 15
        }, {                                                                                             // 14
          $set: {                                                                                        // 17
            "thumb": data                                                                                // 18
          }                                                                                              // 17
        });                                                                                              // 16
      }, function (e) {                                                                                  // 21
        throw e;                                                                                         // 22
      });                                                                                                // 23
    }                                                                                                    // 24
  });                                                                                                    // 7
};                                                                                                       // 26
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
                                                                                                         //
var _configs = require('../configs');                                                                    // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"publications":{"applys.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/applys.js                                                                         //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.publish('applys.status', function () {                                                  // 6
    return _collections.Applys.find({ status: 1 });                                                      // 7
  });                                                                                                    // 8
};                                                                                                       // 9
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"badges.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/badges.js                                                                         //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.publish('badges.list', function () {                                                    // 6
    return _collections.Badges.find();                                                                   // 7
  });                                                                                                    // 8
};                                                                                                       // 9
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"bankcards.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/bankcards.js                                                                      //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.publish('bank.list', function () {                                                      // 6
    return _collections.Bankcards.find();                                                                // 7
  });                                                                                                    // 8
};                                                                                                       // 9
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"banners.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/banners.js                                                                        //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.publish('banners.list', function () {                                                   // 6
    return _collections.Banners.find();                                                                  // 7
  });                                                                                                    // 8
};                                                                                                       // 9
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"departments.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/departments.js                                                                    //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.publish('departments.list', function () {                                               // 6
    return _collections.Departments.find();                                                              // 7
  });                                                                                                    // 8
};                                                                                                       // 9
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"discuz_applys.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/discuz_applys.js                                                                  //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.publish('discuzApplys.list', function () {                                              // 6
    return _collections.DiscuzApplys.find();                                                             // 7
  });                                                                                                    // 8
};                                                                                                       // 9
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"discuz_messages.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/discuz_messages.js                                                                //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.publish('discuzMessages.list', function () {                                            // 6
    return _collections.DiscuzMessages.find();                                                           // 7
  });                                                                                                    // 8
};                                                                                                       // 9
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"discuzs.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/discuzs.js                                                                        //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.publish('discuzs.list', function () {                                                   // 6
    return _collections.Discuzs.find();                                                                  // 7
  });                                                                                                    // 8
};                                                                                                       // 9
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"doctors.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/doctors.js                                                                        //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.publish('doctors.list', function () {                                                   // 6
    return _collections.Doctors.find({}, { fields: { cert: false } });                                   // 7
  });                                                                                                    // 8
};                                                                                                       // 9
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"feilds.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/feilds.js                                                                         //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.publish('visits.list', function () {                                                    // 6
    return _collections.Feilds.find();                                                                   // 7
  });                                                                                                    // 8
};                                                                                                       // 9
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"hospitals.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/hospitals.js                                                                      //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.publish('hospitals', function () {                                                      // 6
    return _collections.Hospitals.find();                                                                // 7
  });                                                                                                    // 8
};                                                                                                       // 9
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./applys","./bankcards","./banners","./discuzs","./discuz_messages","./discuz_applys","./doctors","./users","./news","./recommands","./referrals","./regions","./hospitals","./departments","./badges","./feilds",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/index.js                                                                          //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  (0, _applys2['default'])();                                                                            // 19
  (0, _bankcards2['default'])();                                                                         // 20
  (0, _banners2['default'])();                                                                           // 21
  (0, _discuzs2['default'])();                                                                           // 22
  (0, _discuz_messages2['default'])();                                                                   // 23
  (0, _discuz_applys2['default'])();                                                                     // 24
  (0, _doctors2['default'])();                                                                           // 25
  (0, _users2['default'])();                                                                             // 26
  (0, _news2['default'])();                                                                              // 27
  (0, _recommands2['default'])();                                                                        // 28
  (0, _referrals2['default'])();                                                                         // 29
  (0, _regions2['default'])();                                                                           // 30
  (0, _hospitals2['default'])();                                                                         // 31
  (0, _departments2['default'])();                                                                       // 32
  (0, _badges2['default'])();                                                                            // 33
  (0, _feilds2['default'])();                                                                            // 34
};                                                                                                       // 35
                                                                                                         //
var _applys = require('./applys');                                                                       // 1
                                                                                                         //
var _applys2 = _interopRequireDefault(_applys);                                                          //
                                                                                                         //
var _bankcards = require('./bankcards');                                                                 // 2
                                                                                                         //
var _bankcards2 = _interopRequireDefault(_bankcards);                                                    //
                                                                                                         //
var _banners = require('./banners');                                                                     // 3
                                                                                                         //
var _banners2 = _interopRequireDefault(_banners);                                                        //
                                                                                                         //
var _discuzs = require('./discuzs');                                                                     // 4
                                                                                                         //
var _discuzs2 = _interopRequireDefault(_discuzs);                                                        //
                                                                                                         //
var _discuz_messages = require('./discuz_messages');                                                     // 5
                                                                                                         //
var _discuz_messages2 = _interopRequireDefault(_discuz_messages);                                        //
                                                                                                         //
var _discuz_applys = require('./discuz_applys');                                                         // 6
                                                                                                         //
var _discuz_applys2 = _interopRequireDefault(_discuz_applys);                                            //
                                                                                                         //
var _doctors = require('./doctors');                                                                     // 7
                                                                                                         //
var _doctors2 = _interopRequireDefault(_doctors);                                                        //
                                                                                                         //
var _users = require('./users');                                                                         // 8
                                                                                                         //
var _users2 = _interopRequireDefault(_users);                                                            //
                                                                                                         //
var _news = require('./news');                                                                           // 9
                                                                                                         //
var _news2 = _interopRequireDefault(_news);                                                              //
                                                                                                         //
var _recommands = require('./recommands');                                                               // 10
                                                                                                         //
var _recommands2 = _interopRequireDefault(_recommands);                                                  //
                                                                                                         //
var _referrals = require('./referrals');                                                                 // 11
                                                                                                         //
var _referrals2 = _interopRequireDefault(_referrals);                                                    //
                                                                                                         //
var _regions = require('./regions');                                                                     // 12
                                                                                                         //
var _regions2 = _interopRequireDefault(_regions);                                                        //
                                                                                                         //
var _hospitals = require('./hospitals');                                                                 // 13
                                                                                                         //
var _hospitals2 = _interopRequireDefault(_hospitals);                                                    //
                                                                                                         //
var _departments = require('./departments');                                                             // 14
                                                                                                         //
var _departments2 = _interopRequireDefault(_departments);                                                //
                                                                                                         //
var _badges = require('./badges');                                                                       // 15
                                                                                                         //
var _badges2 = _interopRequireDefault(_badges);                                                          //
                                                                                                         //
var _feilds = require('./feilds');                                                                       // 16
                                                                                                         //
var _feilds2 = _interopRequireDefault(_feilds);                                                          //
                                                                                                         //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }        //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"news.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/news.js                                                                           //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.publish('news.list', function () {                                                      // 6
    return _collections.News.find();                                                                     // 7
  });                                                                                                    // 8
};                                                                                                       // 9
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"recommands.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/recommands.js                                                                     //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.publish('recommand.list', function () {                                                 // 6
    return _collections.Recommands.find();                                                               // 7
  });                                                                                                    // 8
};                                                                                                       // 9
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"referrals.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/referrals.js                                                                      //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.publish('referral.status', function () {                                                // 6
    return _collections.Referrals.find({ status: 1 }, { fields: { "person.pictures": false } });         // 7
  });                                                                                                    // 8
};                                                                                                       // 9
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"regions.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/regions.js                                                                        //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.publish('regions.list', function () {                                                   // 6
    return _collections.Regions.find();                                                                  // 7
  });                                                                                                    // 8
};                                                                                                       // 9
                                                                                                         //
var _collections = require('/lib/collections');                                                          // 1
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 2
                                                                                                         //
var _check = require('meteor/check');                                                                    // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"users.js":["meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/publications/users.js                                                                          //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
Object.defineProperty(exports, "__esModule", {                                                           //
  value: true                                                                                            //
});                                                                                                      //
                                                                                                         //
exports['default'] = function () {                                                                       //
  _meteor.Meteor.publish('users.list', function () {                                                     // 5
    return _meteor.Meteor.users.find();                                                                  // 6
  });                                                                                                    // 7
};                                                                                                       // 8
                                                                                                         //
var _meteor = require('meteor/meteor');                                                                  // 1
                                                                                                         //
var _check = require('meteor/check');                                                                    // 2
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"main.js":["./publications","./methods",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// server/main.js                                                                                        //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
'use strict';                                                                                            //
                                                                                                         //
var _publications = require('./publications');                                                           // 1
                                                                                                         //
var _publications2 = _interopRequireDefault(_publications);                                              //
                                                                                                         //
var _methods = require('./methods');                                                                     // 2
                                                                                                         //
var _methods2 = _interopRequireDefault(_methods);                                                        //
                                                                                                         //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }        //
                                                                                                         //
(0, _publications2['default'])();                                                                        // 4
(0, _methods2['default'])();                                                                             // 5
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./lib/collections/applys.js");
require("./lib/collections/badges.js");
require("./lib/collections/bankcards.js");
require("./lib/collections/banners.js");
require("./lib/collections/departments.js");
require("./lib/collections/discuz_applys.js");
require("./lib/collections/discuzmessages.js");
require("./lib/collections/discuzs.js");
require("./lib/collections/doctors.js");
require("./lib/collections/feilds.js");
require("./lib/collections/hospitals.js");
require("./lib/collections/index.js");
require("./lib/collections/news.js");
require("./lib/collections/recommands.js");
require("./lib/collections/referrals.js");
require("./lib/collections/regions.js");
require("./lib/collections/user_badges.js");
require("./lib/model/facc.js");
require("./lib/model/index.js");
require("./server/configs/index.js");
require("./server/configs/oss.js");
require("./server/configs/sms.js");
require("./server/methods/account_login_with_tel.js");
require("./server/methods/agree_point_apply.js");
require("./server/methods/index.js");
require("./server/methods/notify_referral.js");
require("./server/methods/pass_the_member_vaild.js");
require("./server/methods/save_user_info.js");
require("./server/methods/set_the_member_master.js");
require("./server/methods/upload_banner_thumb.js");
require("./server/methods/upload_discuz_thumb.js");
require("./server/methods/upload_news_thumb.js");
require("./server/methods/upload_records_tables_thumb.js");
require("./server/methods/uploadhospital_thumb.js");
require("./server/publications/applys.js");
require("./server/publications/badges.js");
require("./server/publications/bankcards.js");
require("./server/publications/banners.js");
require("./server/publications/departments.js");
require("./server/publications/discuz_applys.js");
require("./server/publications/discuz_messages.js");
require("./server/publications/discuzs.js");
require("./server/publications/doctors.js");
require("./server/publications/feilds.js");
require("./server/publications/hospitals.js");
require("./server/publications/index.js");
require("./server/publications/news.js");
require("./server/publications/recommands.js");
require("./server/publications/referrals.js");
require("./server/publications/regions.js");
require("./server/publications/users.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
